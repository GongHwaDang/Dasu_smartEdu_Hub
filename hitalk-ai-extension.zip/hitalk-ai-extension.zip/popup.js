document.addEventListener('DOMContentLoaded', () => {
  const classInfoInput = document.getElementById('class_info');
  const apiKeyInput = document.getElementById('factchat_key');
  const baseUrlInput = document.getElementById('factchat_baseurl');
  const saveBtn = document.getElementById('save_btn');

  // 저장되어 있던 설정 불러오기
  chrome.storage.local.get(['class_info', 'factchat_key', 'factchat_baseurl'], (data) => {
    if (data.class_info && classInfoInput) classInfoInput.value = data.class_info;
    if (data.factchat_key && apiKeyInput) apiKeyInput.value = data.factchat_key;
    if (data.factchat_baseurl && baseUrlInput) {
      baseUrlInput.value = data.factchat_baseurl;
    } else if (baseUrlInput) {
      baseUrlInput.value = 'https://factchat-cloud.mindlogic.ai/v1/gateway';
    }
  });

  // 저장 버튼 클릭 시 저장
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const classInfo = classInfoInput ? classInfoInput.value.trim() : '4학년 1반';
      const apiKey = apiKeyInput ? apiKeyInput.value.trim() : '';
      const baseUrl = baseUrlInput ? baseUrlInput.value.trim() : '';

      chrome.storage.local.set({
        class_info: classInfo,
        factchat_key: apiKey,
        factchat_baseurl: baseUrl
      }, () => {
        alert('설정이 안전하게 저장되었습니다!');
      });
    });
  }
});