chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'callFactChat') {
    // 1. 문서에 적힌 Base URL 가져오기 (기본값 설정)
    let baseUrl = (request.baseUrl || 'https://factchat-cloud.mindlogic.ai/v1/gateway').trim();
    
    // 슬래시 중복 제거
    baseUrl = baseUrl.replace(/\/+$/, '');

    // 2. 문서의 전체 엔드포인트 (/chat/completions) 결합
    // 최종 URL: https://factchat-cloud.mindlogic.ai/v1/gateway/chat/completions
    const endpoint = `${baseUrl}/chat/completions`;

    console.log("요청 엔드포인트:", endpoint);

    fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${request.key}`
      },
      body: JSON.stringify({
        // 사용하시려는 모델명을 지정하세요 (예: gemini-2.5-flash, gpt-4o-mini 등)
        model: "gemini-3.5-flash-lite", 
        messages: [
          {
            role: "user",
            content: request.text
          }
        ]
      })
    })
    .then(async (res) => {
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`[${res.status} 오류] ${errorText}`);
      }
      return res.json();
    })
    .then((data) => {
      sendResponse({ success: true, data: data });
    })
    .catch((err) => {
      console.error("API Fetch Error:", err);
      sendResponse({ success: false, error: err.message });
    });

    return true;
  }
});