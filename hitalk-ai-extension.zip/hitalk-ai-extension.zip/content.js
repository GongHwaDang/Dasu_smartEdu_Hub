function injectAIButtons() {
  if (document.getElementById('ai-reply-btn')) return;

  const container = document.createElement('div');
  container.id = 'ai-btn-container';
  container.style.cssText = `
    position: fixed;
    bottom: 25px;
    right: 25px;
    z-index: 99999;
    display: flex;
    gap: 10px;
  `;

  const replyBtn = document.createElement('button');
  replyBtn.id = 'ai-reply-btn';
  replyBtn.innerText = '🤖 AI 답장 추천';
  replyBtn.type = 'button';
  replyBtn.style.cssText = getButtonStyle('#3b82f6');
  replyBtn.addEventListener('click', handleAIReply);

  const sendBtn = document.createElement('button');
  sendBtn.id = 'ai-send-btn';
  sendBtn.innerText = '✉️ AI 하이톡 작성';
  sendBtn.type = 'button';
  sendBtn.style.cssText = getButtonStyle('#8b5cf6');
  sendBtn.addEventListener('click', handleAISendPrompt);

  container.appendChild(replyBtn);
  container.appendChild(sendBtn);
  document.body.appendChild(container);
}

function getButtonStyle(bgColor) {
  return `
    padding: 9px 16px;
    background-color: ${bgColor};
    color: white;
    border: none;
    border-radius: 20px;
    font-size: 13px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    transition: all 0.2s ease;
  `;
}

function handleAIReply() {
  let messageText = "";

  const selection = window.getSelection().toString().trim();
  if (selection) {
    messageText = selection;
  } else {
    const chatBubbles = document.querySelectorAll('.message-bubble, .chat-item, [class*="message"], [class*="talk"], [class*="content"]');
    if (chatBubbles.length > 0) {
      for (let i = chatBubbles.length - 1; i >= 0; i--) {
        const text = chatBubbles[i].innerText.trim();
        if (text && text.length > 1 && !text.includes('님이 입장하셨습니다') && !text.includes('새로운 메시지')) {
          messageText = text;
          break;
        }
      }
    }
    if (!messageText) {
      const mainChat = document.querySelector('[class*="chat-room"]') || document.body;
      messageText = mainChat.innerText.trim();
    }
  }

  if (!messageText) {
    alert('인식된 메시지가 없습니다. 대화방이 열려있는지 확인해 주세요!');
    return;
  }

  chrome.storage.local.get(['factchat_key', 'factchat_baseurl', 'class_info'], (config) => {
    if (!config.factchat_key) {
      alert('API Key를 먼저 저장해 주세요!');
      return;
    }

    const rawClassInfo = config.class_info && config.class_info.trim() !== '' ? config.class_info : '4학년 1반';
    const classInfo = rawClassInfo.replace('학년 ', '-').replace('반', '').trim();
    const greetingHeader = `안녕하세요 보호자님, ${classInfo} 담임교사입니다.`;

    const promptInstruction = `
[최우선 필수 규칙]
1. 인사말: 모든 답장([공감형], [안내/확인형], [간결형])의 첫 문장은 예외 없이 반드시 "${greetingHeader}"로 정확히 시작해라.
2. 호칭: 상대방을 부를 때 오직 '보호자님'만 사용해라 ('어머니', '어머님', '아버님', '학부모님' 및 교사 성함 표기 엄격 금지).
3. 행정 안내 (나이스 결석신고서 엄격한 조건부 적용):
   - **오직 학생이 학교에 결석(또는 병결)하여 아예 등교하지 않은 명확한 상황일 때만** 답장 본문 내에 "추후 시간 되실 때 나이스 학부모 서비스를 통해 결석신고서를 제출해 주시면 감사하겠습니다."라는 안내 멘트를 포함해라.
   - **만약 아이가 등교는 하였으나 상태가 안 좋아 조퇴 가능성을 물어보는 경우, 단순 두통/미열, 지각, 병원 방문 후 등교 등의 상황이라면 절대 결석신고서 안내 멘트를 포함하지 마라.** 아이의 건강 상태를 염려하고 살피는 공감과 안내 메시지만 작성해라.

[역할 및 지침]
초등학교 ${classInfo} 담임교사의 학부모 상담 메시지 작성 보조 AI이다.
수신된 메시지를 바탕으로 정중하고 따뜻하며 깔끔한 답장 초안 3가지를 작성해라.

1. 서론이나 부연설명 없이 즉시 "[공감형]" 항목부터 출력을 시작해라.
2. 3가지 타입([공감형], [안내/확인형], [간결형]) 모두 완벽한 문장 구조로 마무리해라.

수신된 메시지:
"${messageText}"
`;

    showModal(`AI가 ${classInfo} 담임교사 맞춤 답장을 작성 중입니다...`);

    chrome.runtime.sendMessage({
      action: 'callFactChat',
      key: config.factchat_key,
      baseUrl: config.factchat_baseurl,
      text: promptInstruction
    }, (response) => {
      if (response && response.success) {
        const content = response.data.choices[0].message.content;
        renderResponseWithCopyButtons(content, greetingHeader);
      } else {
        showModal(`오류가 발생했습니다: ${response ? response.error : '응답 없음'}`);
      }
    });
  });
}

function handleAISendPrompt() {
  showInputModal();
}

function showInputModal() {
  let modal = document.getElementById('ai-reply-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'ai-reply-modal';
    modal.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 100000;
      width: 520px;
      max-height: 82vh;
      background: #ffffff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.25);
      display: flex;
      flex-direction: column;
      font-family: sans-serif;
    `;
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid #eee; padding-bottom:10px;">
      <h3 style="margin:0; color:#1e293b; font-size:16px;">✉️ 선생님 발신 메시지 생성</h3>
      <button id="close-modal-btn" style="padding:4px 10px; background:#e2e8f0; border:none; border-radius:4px; cursor:pointer;">닫기</button>
    </div>
    <div style="margin-bottom:12px;">
      <label style="font-size:13px; font-weight:bold; color:#475569; display:block; margin-bottom:6px;">
        학부모님께 전달할 핵심 내용을 간단히 적어주세요:
      </label>
      <textarea id="teacher-input-text" placeholder="예: 오늘 체육시간에 무릎을 살짝 긁혀서 보건실 소독 완료했습니다. 집에서 상태 확인 부탁드립니다." 
        style="width:100%; height:90px; padding:10px; box-sizing:border-box; border-radius:6px; border:1px solid #cbd5e1; font-size:13px; resize:none;"></textarea>
    </div>
    <button id="generate-send-msg-btn" style="padding:10px; background-color:#8b5cf6; color:white; border:none; border-radius:6px; font-weight:bold; cursor:pointer;">
      ✨ 하이톡 메시지 생성하기
    </button>
    <div id="ai-reply-content" style="overflow-y:auto; flex:1; line-height:1.6; margin-top:15px;"></div>
    <div style="text-align:right; font-size:11px; color:#94a3b8; font-weight:bold; margin-top:10px; border-top:1px solid #f1f5f9; padding-top:8px;">MADE BY 강경진</div>
  `;

  document.getElementById('close-modal-btn').addEventListener('click', () => { modal.style.display = 'none'; });

  document.getElementById('generate-send-msg-btn').addEventListener('click', () => {
    const userInput = document.getElementById('teacher-input-text').value.trim();
    if (!userInput) {
      alert('전달할 핵심 내용을 입력해 주세요!');
      return;
    }

    chrome.storage.local.get(['factchat_key', 'factchat_baseurl', 'class_info'], (config) => {
      if (!config.factchat_key) {
        alert('API Key를 먼저 저장해 주세요!');
        return;
      }

      const rawClassInfo = config.class_info && config.class_info.trim() !== '' ? config.class_info : '4학년 1반';
      const classInfo = rawClassInfo.replace('학년 ', '-').replace('반', '').trim();
      const greetingHeader = `안녕하세요 보호자님, ${classInfo} 담임교사입니다`;

      const promptInstruction = `
[최우선 필수 규칙]
1. 인사말: 모든 작성안([다정형], [정중/안내형], [간결형])의 첫 문장은 예외 없이 반드시 "${greetingHeader}"로 정확히 시작해라.
2. 호칭: 상대방을 부를 때 오직 '보호자님'만 사용해라 ('어머니', '어머님', '아버님', '학부모님' 금지).

[역할 및 지침]
초등학교 ${classInfo} 담임교사가 학부모님께 먼저 발신할 하이톡 메시지 작성 보조 AI이다.
선생님이 전달하고자 하는 내용을 바탕으로 학부모님께 보낼 정중하고 깔끔한 메시지 초안 3가지를 작성해라.

1. 서론이나 부연설명 없이 즉시 "[다정형]" 항목부터 출력을 시작해라.
2. 3가지 타입([다정형], [정중/안내형], [간결형])으로 다채롭게 구성해라.

선생님이 전달할 내용:
"${userInput}"
`;

      const contentDiv = document.getElementById('ai-reply-content');
      contentDiv.innerHTML = `AI가 ${classInfo} 담임교사 발신 메시지를 다듬는 중입니다...`;

      chrome.runtime.sendMessage({
        action: 'callFactChat',
        key: config.factchat_key,
        baseUrl: config.factchat_baseurl,
        text: promptInstruction
      }, (response) => {
        if (response && response.success) {
          const content = response.data.choices[0].message.content;
          renderResponseWithCopyButtons(content, greetingHeader, ['다정형', '정중/안내형', '간결형']);
        } else {
          contentDiv.innerHTML = `오류가 발생했습니다: ${response ? response.error : '응답 없음'}`;
        }
      });
    });
  });

  modal.style.display = 'flex';
}

function showModal(initialText) {
  let modal = document.getElementById('ai-reply-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'ai-reply-modal';
    modal.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 100000;
      width: 520px;
      max-height: 82vh;
      background: #ffffff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.25);
      display: flex;
      flex-direction: column;
      font-family: sans-serif;
    `;
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid #eee; padding-bottom:10px;">
      <h3 style="margin:0; color:#1e293b; font-size:16px;">✨ AI 추천 답장</h3>
      <button id="close-modal-btn" style="padding:4px 10px; background:#e2e8f0; border:none; border-radius:4px; cursor:pointer;">닫기</button>
    </div>
    <div id="ai-reply-content" style="overflow-y:auto; flex:1; line-height:1.6;">${initialText}</div>
    <div style="text-align:right; font-size:11px; color:#94a3b8; font-weight:bold; margin-top:10px; border-top:1px solid #f1f5f9; padding-top:8px;">MADE BY 강경진</div>
  `;

  document.getElementById('close-modal-btn').addEventListener('click', () => {
    modal.style.display = 'none';
  });

  modal.style.display = 'flex';
}

function renderResponseWithCopyButtons(rawText, greetingHeader, customCategories) {
  const container = document.getElementById('ai-reply-content');
  if (!container) return;

  container.innerHTML = ''; 
  
  let safeText = rawText.replace(/어머니|어머님|아버님/g, '보호자님');

  const categoryTypes = customCategories || ['공감형', '안내/확인형', '간결형'];
  let count = 0;

  categoryTypes.forEach((type) => {
    const regex = new RegExp(`\\[${type}\\]([\\s\\S]*?)(?=\\[(?:공감형|안내\\/확인형|간결형|다정형|정중\\/안내형)\\]|$)`, 'i');
    const match = safeText.match(regex);

    if (match && match[1]) {
      let bodyText = match[1].trim();

      if (bodyText) {
        count++;

        if (/^안녕하세요\s*보호자님/i.test(bodyText)) {
          bodyText = bodyText.replace(/^안녕하세요\s*보호자님[^\n.!]*/i, greetingHeader);
        } else {
          bodyText = `${greetingHeader}\n${bodyText}`;
        }

        const card = document.createElement('div');
        card.style.cssText = "background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin-bottom: 12px;";

        const titleDiv = document.createElement('div');
        titleDiv.style.cssText = "font-weight: bold; color: #7c3aed; margin-bottom: 6px;";
        titleDiv.innerText = `[${type}]`;
        card.appendChild(titleDiv);

        const bodyDiv = document.createElement('div');
        bodyDiv.style.cssText = "white-space: pre-wrap; margin-bottom: 10px; color: #1e293b;";
        bodyDiv.innerText = bodyText;
        card.appendChild(bodyDiv);

        const copyBtn = document.createElement('button');
        copyBtn.innerText = '📋 이 내용 복사';
        copyBtn.style.cssText = "padding: 6px 12px; background-color: #16a34a; color: white; border: none; border-radius: 4px; cursor: pointer; display: block; margin-left: auto;";

        copyBtn.addEventListener('click', () => {
          navigator.clipboard.writeText(bodyText).then(() => {
            copyBtn.innerText = '✅ 복사 완료!';
            setTimeout(() => { copyBtn.innerText = '📋 이 내용 복사'; }, 2000);
          });
        });

        card.appendChild(copyBtn);
        container.appendChild(card);
      }
    }
  });

  if (count === 0) {
    container.innerText = safeText;
  }
}

setInterval(injectAIButtons, 1000);